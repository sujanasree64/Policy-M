package com.hexaware.policymanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicymanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
