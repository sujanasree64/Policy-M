package com.hexaware.policymanagementsystem.exception;


public class ResourceNotFoundException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 235361947967194109L;

	public ResourceNotFoundException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
}

