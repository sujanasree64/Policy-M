package com.hexaware.policymanagementsystem.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.policymanagementsystem.entity.Policy;

public interface PolicyRepository extends JpaRepository<Policy, Long> {
	
	
	


}
